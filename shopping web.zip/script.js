// Sample Product Data
const products = [
    { id: 1, name: "Modern Laptop", price: 999.99, category: "electronics", image: "💻", desc: "High-performance laptop for pros." },
    { id: 2, name: "Cotton T-Shirt", price: 25.00, category: "clothing", image: "👕", desc: "100% organic cotton comfort." },
    { id: 3, name: "Science Fiction Novel", price: 15.50, category: "books", image: "📚", desc: "A journey through the stars." },
    { id: 4, name: "Garden Tool Set", price: 45.00, category: "home", image: "🪴", desc: "Essential tools for your garden." },
    { id: 5, name: "Wireless Headphones", price: 199.99, category: "electronics", image: "🎧", desc: "Noise-cancelling crystal clear audio." }
];

let cart = [];

// Initialize Page
document.addEventListener('DOMContentLoaded', () => {
    displayProducts(products);
});

// Display Products
function displayProducts(productsToDisplay) {
    const grid = document.getElementById('productsGrid');
    grid.innerHTML = productsToDisplay.map(product => `
        <div class="product-card">
            <div class="product-image">${product.image}</div>
            <div class="product-info">
                <h3 class="product-name">${product.name}</h3>
                <p class="product-price">$${product.price.toFixed(2)}</p>
                <p class="product-description">${product.desc}</p>
                <button class="add-to-cart" onclick="addToCart(${product.id})">Add to Cart</button>
            </div>
        </div>
    `).join('');
}

// Cart Functionality
function toggleCart() {
    document.getElementById('cartSidebar').classList.toggle('open');
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ ...product, quantity: 1 });
    }
    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById('cartItems');
    const cartCount = document.getElementById('cartCount');
    const cartTotal = document.getElementById('cartTotal');

    cartCount.innerText = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item">
            <div class="cart-item-info">
                <p class="cart-item-name">${item.name}</p>
                <p class="cart-item-price">$${(item.price * item.quantity).toFixed(2)}</p>
                <div class="quantity-controls">
                    <span>Qty: ${item.quantity}</span>
                </div>
            </div>
        </div>
    `).join('');

    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cartTotal.innerText = `$${total.toFixed(2)}`;
}

// Filters & Search
function filterCategory(category) {
    const filtered = category === 'all' ? products : products.filter(p => p.category === category);
    displayProducts(filtered);
}

function searchProducts() {
    const query = document.getElementById('searchInput').value.toLowerCase();
    const filtered = products.filter(p => p.name.toLowerCase().includes(query));
    displayProducts(filtered);
}

function checkout() {
    if (cart.length === 0) return alert("Your cart is empty!");
    alert("Thank you for your purchase!");
    cart = [];
    updateCart();
    toggleCart();
}